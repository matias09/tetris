#include "LineShape.h"

LineShape::LineShape()
{
    _mMatrix = new bool*[SHAPE_DIMENSION];
    for (int i = 0; i < SHAPE_DIMENSION; i++)
    {
        _mMatrix[i] = new bool[SHAPE_DIMENSION];
    }
}

LineShape::~LineShape()
{
   if (_mMatrix != nullptr)
   {
       for (int i = 0; i < SHAPE_DIMENSION; ++i)
       {
           delete[] _mMatrix[i];
           _mMatrix[i] = nullptr;
       } 

	   delete[] _mMatrix;
       _mMatrix = nullptr;
   }
}

bool** LineShape::Create()
{
    RotateToUp();
    return _mMatrix;
}

void LineShape::Rotate()
{
    switch (_mRotateTo)
    {
    case 1:
        _RotateToUp();
    break;
    case 2:
        _mRotateTo = 0;
        _RotateToLeft();
    break;
    }

    _mRotateTo++;
}

void LineShape::RotateToUp()
{
	_mRows = 4;
	_mColumns = 1;

	for (unsigned short int i = 0; i < rows; i++)
	{
		_mMatrix[i][0] = 1;
	}

	SetColumns(_mColumns);
	SetRows(_mRows);
}

void LineShape::RotateToLeft()
{
	_mRows = 1;
	_mColumns = 4;

	for (unsigned short int j = 0; j < rows; j++)
	{
		_mMatrix[0][j] = 1;
	}

	SetColumns(_mColumns);
	SetRows(_mRows);
}
