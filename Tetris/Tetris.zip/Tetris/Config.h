
namespace INPUT_CONFIG
{
    enum INPUT_IMPLEMENTATION 
    {
        SDL
    };
    
};

namespace GRAPHIC_CONFIG
{
    enum GRAPHIC_IMPLEMENTATION 
    {
        SDL
    };
};
